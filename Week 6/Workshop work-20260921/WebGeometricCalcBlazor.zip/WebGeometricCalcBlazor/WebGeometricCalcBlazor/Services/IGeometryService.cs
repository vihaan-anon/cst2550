﻿using WebGeometricCalcBlazor.Models;

namespace WebGeometricCalcBlazor.Services
{
    public interface IGeometryService
    {
        ShapeResult Calculate(ShapeRequest request);
        List<string> GetSupportedShapes();
        List<string> GetShapeProperties(string shapeName);

    }
}
