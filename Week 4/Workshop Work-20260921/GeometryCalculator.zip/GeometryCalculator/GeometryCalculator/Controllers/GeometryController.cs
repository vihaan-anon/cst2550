﻿using GeometryCalculator.Models;
using GeometryCalculator.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GeometryCalculator.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GeometryController : ControllerBase
    {
        private readonly IGeometryService _geometryService;

        public GeometryController(IGeometryService geometryService)
        {
            _geometryService = geometryService;
        }

        /// <summary>
        /// Returns the list of supported shapes.
        /// </summary>
        [HttpGet("shapes")]
        public ActionResult<List<string>> GetShapes()
        {
            return Ok(_geometryService.GetSupportedShapes());
        }

        /// <summary>
        /// Returns the required properties for a given shape.
        /// </summary>
        [HttpGet("shapes/{shapeName}/properties")]
        public ActionResult<List<string>> GetShapeProperties(string shapeName)
        {
            var propertiesMap = new Dictionary<string, List<string>>(
                StringComparer.OrdinalIgnoreCase)
            {
                { "circle",        new List<string> { "radius" } },
                { "rectangle",     new List<string> { "length", "width" } },
                { "triangle",      new List<string> { "sideA", "sideB", "sideC" } },
                { "square",        new List<string> { "side" } },
                { "ellipse",       new List<string> { "semiMajorAxis", "semiMinorAxis" } },
                { "parallelogram", new List<string> { "base", "height", "side" } },
                { "trapezoid",     new List<string> { "topBase", "bottomBase",
                                                       "height", "leftSide", "rightSide" } }
            };

            if (!propertiesMap.ContainsKey(shapeName))
                return NotFound($"Shape '{shapeName}' is not supported.");

            return Ok(propertiesMap[shapeName]);
        }

        /// <summary>
        /// Calculates the area and circumference of the given shape.
        /// </summary>
        [HttpPost("calculate")]
        public ActionResult<ShapeResult> Calculate([FromBody] ShapeRequest request)
        {
            try
            {
                var result = _geometryService.Calculate(request);
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
    }
}
