﻿using GeometryCalculator.Models;

namespace GeometryCalculator.Services
{
    public interface IGeometryService
    {
        ShapeResult Calculate(ShapeRequest request);
        List<string> GetSupportedShapes();

    }
}
